package com.csye6225.fall.Student_Info_System.database;

import java.util.HashMap;

import com.csye6225.fall.Student_Info_System.datamodel.Course;
import com.csye6225.fall.Student_Info_System.datamodel.Lecture;
import com.csye6225.fall.Student_Info_System.datamodel.Professor;
import com.csye6225.fall.Student_Info_System.datamodel.Program;
import com.csye6225.fall.Student_Info_System.datamodel.Student;

public class InMemoryDatabase {
	private static HashMap<Long,Student> stuDB=new HashMap<>();
	private static HashMap<Long,Professor> proDB=new HashMap<>();
	private static HashMap<Long, Course> courseDB=new HashMap<>();
	private static HashMap<Long,Lecture> lectureDB=new HashMap<>();
	private static HashMap<Long,Program> programDB=new HashMap<>();
	public static HashMap<Long, Student> getStuDB() {
		return stuDB;
	}
	
	static{
		Program p=new Program("Information System");
		Course c=new Course("CSYE6225-Network Structure & Cloud Computing", 0, "board1", "roster1", null, null, 1);
		Student s=new Student("Yue Tang","Image","Information System");
		Lecture l=new Lecture();
		lectureDB.put((long) 1, l);
		stuDB.put(1l, s);
		programDB.put(1l, p);
		courseDB.put(2l, c);
		
		
	}
	
	
	
	public static HashMap<Long, Professor> getProDB() {
		return proDB;
	}
	public static HashMap<Long, Course> getCourseDB() {
		return courseDB;
	}
	public static HashMap<Long, Lecture> getLectureDB() {
		return lectureDB;
	}
	public static HashMap<Long, Program> getProgramDB() {
		return programDB;
	}

	

}
