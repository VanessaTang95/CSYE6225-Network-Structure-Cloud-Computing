package com.csye6225.fall.Student_Info_System.datamodel;

import java.util.List;

public class Course {
	private long courseId;
	private String courseName;
	private List<String> lectures;
	private String board;
	private String roster;
	private String associate_Pro;
	private String tA;
	private List<String> allStudents;
	private long pro_Id;
	private long programId;
	
	public Course() {}
	
	public Course(String courseName,long pro_id,String board,String roster,String asso_pro, String tA,long programId) {
		this.courseName=courseName;
		this.pro_Id=pro_id;
		this.board=board;
		this.roster=roster;
		this.associate_Pro=asso_pro;
		this.tA=tA;
		this.programId=programId;
	}

	public long getProgramId() {
		return programId;
	}

	public void setProgramId(long programId) {
		this.programId = programId;
	}

	public long getPro_Id() {
		return pro_Id;
	}

	public void setPro_Id(long pro_Id) {
		this.pro_Id = pro_Id;
	}

	public long getCourseId() {
		return courseId;
	}

	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public List<String> getLectures() {
		return lectures;
	}

	public void setLectures(List<String> lectures) {
		this.lectures = lectures;
	}

	public String getBoard() {
		return board;
	}

	public void setBoard(String board) {
		this.board = board;
	}

	public String getRoster() {
		return roster;
	}

	public void setRoster(String roster) {
		this.roster = roster;
	}

	public String getAssociate_Pro() {
		return associate_Pro;
	}

	public void setAssociate_Pro(String associate_Pro) {
		this.associate_Pro = associate_Pro;
	}

	public String gettA() {
		return tA;
	}

	public void settA(String tA) {
		this.tA = tA;
	}

	public List<String> getAllStudents() {
		return allStudents;
	}

	public void setAllStudents(List<String> allStudents) {
		this.allStudents = allStudents;
	}
	
}
