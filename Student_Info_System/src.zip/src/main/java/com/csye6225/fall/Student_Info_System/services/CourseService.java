package com.csye6225.fall.Student_Info_System.services;

	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;

import com.csye6225.fall.Student_Info_System.database.InMemoryDatabase;
import com.csye6225.fall.Student_Info_System.datamodel.Course;

	public class CourseService {
		static HashMap<Long,Course> course_Map=InMemoryDatabase.getCourseDB();

	//getting a list of all courses
		public List<Course> getAllCourse(){
			ArrayList<Course> list=new ArrayList<>();
			for(Course c:course_Map.values()) {
				list.add(c);
			}
			return list;
		}

	//adding a course
		public void addCourse(String courseName, long pro_id,String board,String roster,String asso_pro,String tA,long programId) {
				//generate next id automatic
			long nextId=course_Map.size()+1;
			
			Course c=new Course(courseName,pro_id,board,roster,asso_pro,tA,programId);
			course_Map.put(nextId, c);
				
		}
		//getting one course
		public Course getOneCourse(Long courseId) {
			return course_Map.get(courseId);
		}
		
		//deleting one course
		public Course deleteCourse(Long courseId) {
			Course del=course_Map.get(courseId);
			course_Map.remove(courseId);
			return del;
		}
		
		//updating Course 
		public Course updateCourseInfo(Long id, Course c) {
			Course old=course_Map.get(id);
			id=old.getCourseId();
			c.setCourseId(id);	
			course_Map.put(id, c);
			return c;
		}
		
		
		//get courses in a program
		public List<Course> getCourseByProgram(long programId){
			ArrayList<Course> list=new ArrayList<>();
			for(Course c:course_Map.values()) {
				if(c.getProgramId()==programId) {
					list.add(c);
				}
			}
			return list;
		}
	}

