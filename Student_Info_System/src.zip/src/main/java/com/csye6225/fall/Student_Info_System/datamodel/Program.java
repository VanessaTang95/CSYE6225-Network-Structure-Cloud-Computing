package com.csye6225.fall.Student_Info_System.datamodel;

import java.util.List;

public class Program {
	private String programName;
	private long programId;
	private List<String> coursesOfProgram;
	private List<Long> enrolledStuId;
	private List<Long> professorsId;
	
	public Program() {}
	
	public Program(String programName) {
		this.programName=programName;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public long getProgramId() {
		return programId;
	}

	public void setProgramId(long programId) {
		this.programId = programId;
	}

	public List<String> getCoursesOfProgram() {
		return coursesOfProgram;
	}

	public void setCoursesOfProgram(List<String> coursesOfProgram) {
		this.coursesOfProgram = coursesOfProgram;
	}

	public List<Long> getEnrolledStuId() {
		return enrolledStuId;
	}

	public void setEnrolledStuId(List<Long> enrolledStuId) {
		this.enrolledStuId = enrolledStuId;
	}

	public List<Long> getProfessorsId() {
		return professorsId;
	}

	public void setProfessorsId(List<Long> professorsId) {
		this.professorsId = professorsId;
	}
	
	
}
