package com.csye6225.fall.Student_Info_System.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.csye6225.fall.Student_Info_System.datamodel.Lecture;

public class LectureService {
	static HashMap<Long,Lecture>lec_Map=new HashMap<>();
	
	//get All lecture
	public List<Lecture> getAllLectures() {
		ArrayList<Lecture> list=new ArrayList<>();
		for(Lecture l:lec_Map.values()) {
			list.add(l);
		}
		return list;
	}
	//get lecture by course
	public List<Lecture> getLectureByCourse(long courseId){
		ArrayList<Lecture> list=new ArrayList<>();
		for(Lecture l:lec_Map.values()) {
			if(l.getLec_course_id()==courseId) {
				list.add(l);
			}
		}
		return list;
	}
	//get lecture by id
	public Lecture getLectureById(long lectureId) {
		return lec_Map.get(lectureId);
	}
	
	//add lecture to courses
	public void addLecture(String name, long course_id) {
		long nextId=lec_Map.size()+1;
		Lecture l=new Lecture(name,course_id);
		lec_Map.put(nextId, l);
	}
	
	
	//delete lecture
	public Lecture deleteLectureById(long lectureId) {
		Lecture del=lec_Map.get(lectureId);
		lec_Map.remove(lectureId);
		return del;
	}
	//updating lecture
	public Lecture updateLecture(long id, Lecture l) {
		Lecture old=lec_Map.get(id);
		id=old.getLec_Id();
		l.setLec_Id(id);
		lec_Map.put(id, l);
		return l;
	}
}
