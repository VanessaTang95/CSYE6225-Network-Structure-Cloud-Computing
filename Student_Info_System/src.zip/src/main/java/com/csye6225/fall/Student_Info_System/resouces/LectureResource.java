package com.csye6225.fall.Student_Info_System.resouces;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.csye6225.fall.Student_Info_System.datamodel.Lecture;
import com.csye6225.fall.Student_Info_System.services.LectureService;



@Path("lectures")
public class LectureResource {
	LectureService lecService=new LectureService();
	//get all lectures
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Lecture> getLectures(){
		return lecService.getAllLectures();
	}

	//get lectures by course
	@GET
	@Path("/getLecturesByCourse/{courseId}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Lecture> getLecturesByCourse(@QueryParam("courseId")long courseId){
		return lecService.getLectureByCourse(courseId);
	}
	
	//get lecture by id
	@GET
	@Path("/{lectureId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Lecture getLecture(@PathParam("lectureId")long lectureId) {
		return lecService.getLectureById(lectureId);
	}
	
	//Delete
	@DELETE
	@Path("/{lectureId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Lecture deleteLecture(@PathParam("lectureId")long lectureId) {
		return lecService.deleteLectureById(lectureId);
	}
	
		public void addLecture(String name,long courseId) {
		lecService.addLecture(name, courseId);	
		}
	
	//update
	@PUT
	@Path("/{lectureId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Lecture updateLecture(@PathParam("lectureId")long lectureId,Lecture l) {
		return lecService.updateLecture(lectureId, l);
	}
	
	
}

